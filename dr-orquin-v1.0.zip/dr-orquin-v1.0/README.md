# Dr. Jorge Orquin — Sitio Web v1.0

Sitio web profesional para consultorio de gerontología.

## Stack
- Node.js + Express
- EJS (motor de vistas con layout automático)
- Nodemailer (formulario de contacto)
- CSS puro con variables

## Estructura
```
dr-orquin-v1.0/
├── app.js                  ← Servidor principal
├── package.json
├── .env.example            ← Copiar a .env y completar
├── config/
│   └── doctor.js           ← Datos del consultorio (fuente única)
├── routes/
│   ├── index.js            ← GET / y GET /servicios
│   └── contacto.js         ← GET y POST /contacto
├── views/
│   ├── layouts/
│   │   └── main.ejs        ← Layout principal
│   ├── home.ejs
│   ├── servicios.ejs
│   └── contacto.ejs
└── public/
    ├── css/style.css
    ├── js/main.js
    └── img/                ← Agregar jorge.png aquí
```

## Instalación
```bash
npm install
cp .env.example .env
# Completar .env con credenciales SMTP
npm start
```

## Notas
- Agregar `public/img/jorge.png` con la foto del doctor
- Editar `config/doctor.js` para cambiar datos del consultorio
