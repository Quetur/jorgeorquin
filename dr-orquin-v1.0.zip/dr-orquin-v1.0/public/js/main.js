// scripts del cliente
